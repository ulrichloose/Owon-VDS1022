On my two macs there are screenerrors - the transparency is not correct. I think the App is running on windows with JAVA 1.6 which is delivered with the app. So I tried to use Apple Java 1.6 for the OWON 1022 Program.

You have to load the last official Java from Apple -> https://support.apple.com/kb/dl1572 and install it. No sorry - all newer Java Installations are not touched.

If that ist done, you can test my Version of the OWON PC Frontend. It has no installation routines so it can only run if the official Version has done the job.

My Problem (:-) in the moment I don´t own such a scope but want to buy one. So I am interested in some feedback because the transparency errors are a no go...

Thanks in advance